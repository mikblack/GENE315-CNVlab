# Use this link for nicely formatted instructions:
# https://github.com/mikblack/GENE315-CNVlab/blob/master/GENE315-CNV_lab-week1.md

# To get started - read in teh FCGR data:

fcgrDat = read.csv('FCGR-counts.csv', row.names = 1)
